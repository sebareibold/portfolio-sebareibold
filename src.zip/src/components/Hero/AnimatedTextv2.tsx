import React, { JSX } from 'react';
import { motion } from 'framer-motion';

interface AnimatedTextProps {
  text: string;
  el?: keyof JSX.IntrinsicElements;
  className?: string;
  once?: boolean;
  delay?: number;
}

const AnimatedText: React.FC<AnimatedTextProps> = ({
  text,
  className = 'custom-text-hero',
  once = false,
  delay = 0
}) => {
  // Animation variants for the container
  const container = {
    hidden: {
      opacity: 0
    },
    visible: (i = 1) => ({
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
        delayChildren: delay * i
      }
    })
  };

  // Efecto de máquina de escribir con glitch
  const child = {
    visible: {
      opacity: 1,
      y: 0,
      scaleY: 1,
      skewX: 0,
      filter: 'blur(0px)',
      transition: {
        type: 'spring',
        damping: 12,
        stiffness: 200,
        duration: 0.6
      }
    },
    hidden: {
      opacity: 0,
      y: 50,
      scaleY: 0.3,
      skewX: 45,
      filter: 'blur(10px)',
      transition: {
        type: 'spring',
        damping: 12,
        stiffness: 200
      }
    }
  };

  return (
    <motion.div 
      style={{
        overflow: 'visible',
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'center'
      }} 
      variants={container} 
      initial="hidden" 
      whileInView="visible" 
      viewport={{ once }}
    >
      {text.split('').map((char, index) => (
        <motion.span 
          key={index} 
          variants={child} 
          className={className}
          style={{
            display: 'inline-block',
            transformOrigin: 'bottom center'
          }}
          whileHover={{
            y: -5,
            scale: 1.05,
            color: '#a602f2',
            textShadow: '0 0 20px #8a02c9, 0 0 40px #8a02c9',
            transition: { 
              duration: 0.3,
              ease: 'easeOut'
            }
          }}
          animate={{
            textShadow: [
              '0 0 0px transparent',
              '0 0 2px rgba(255,255,255,0.5)',
              '0 0 0px transparent'
            ]
          }}
          transition={{
            textShadow: {
              duration: 2,
              repeat: Infinity,
              delay: index * 0.1
            }
          }}
        >
          {char === ' ' ? '\u00A0' : char}
        </motion.span>
      ))}
    </motion.div>
  );
};

export default AnimatedText;